from scripts.helpful_scripts import issue_tokens

def main():
    issue_tokens()