This repo contains all the code associated with the freecodecamp video. 

This repo was modified from the [longer form repo located here](https://github.com/PatrickAlphaC/defi-stake-yield-brownie)


If you're looking for info on issuing tokens, you can call the function directly from etherscan, or write a python script to call the function.

Good luck :)
